import { useEffect, useState } from "react";
import { DemoResponse } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import SwipeDeck from "@/components/SwipeDeck";
import { Sparkles, Zap, Users, Workflow, Wand2 } from "lucide-react";

export default function Index() {
  const [serverMessage, setServerMessage] = useState("");

  useEffect(() => {
    fetchDemo();
  }, []);

  const fetchDemo = async () => {
    try {
      const response = await fetch("/api/demo");
      const data = (await response.json()) as DemoResponse;
      setServerMessage(data.message);
    } catch (error) {
      // keep silent in UI
      console.error("Error fetching demo:", error);
    }
  };

  return (
    <div className="space-y-24">
      <section className="relative overflow-hidden rounded-3xl border bg-gradient-to-br from-primary/10 via-primary/5 to-accent/40 p-8 md:p-12">
        <div className="mx-auto grid max-w-6xl items-center gap-10 md:grid-cols-2">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border bg-background/70 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" /> GitHub × Tinder × Hackathon
            </div>
            <h1 className="mt-4 text-4xl font-extrabold tracking-tight md:text-5xl">
              Find your perfect hackathon team with AI
            </h1>
            <p className="mt-4 text-base text-muted-foreground md:text-lg">
              Match My Stack connects builders by skills, availability, and vibes. Swipe to match with teammates and projects, then form teams and ship.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Button size="lg" asChild>
                <a href="/auth">Create your profile</a>
              </Button>
              <Button variant="secondary" size="lg" asChild>
                <a href="#demo">Try the swipe demo</a>
              </Button>
            </div>
            {serverMessage && (
              <p className="mt-3 text-xs text-muted-foreground">Server says: {serverMessage}</p>
            )}
            <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
              <Badge variant="secondary">OAuth GitHub/Google</Badge>
              <Badge variant="secondary">Postgres</Badge>
              <Badge variant="secondary">Realtime chat</Badge>
            </div>
          </div>
          <div id="demo" className="flex items-center justify-center">
            <SwipeDeck />
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 md:grid-cols-3">
        <Feature
          icon={<Wand2 className="h-5 w-5" />}
          title="AI recommendations"
          desc="Content-based matching on skills, timezones, and complementarity."
        />
        <Feature
          icon={<Users className="h-5 w-5" />}
          title="Team & project profiles"
          desc="Create project briefs, declare stacks, and recruit the right roles."
        />
        <Feature
          icon={<Zap className="h-5 w-5" />}
          title="Swipe interface"
          desc="Fast, addictive UX powered by smooth motion and clear signals."
        />
      </section>

      <section className="mx-auto grid max-w-6xl items-stretch gap-6 md:grid-cols-2">
        <Card className="bg-gradient-to-br from-card to-muted/40">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold">How it works</h3>
            <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
              <li>Sign in with GitHub. We import your stack and repos.</li>
              <li>Set availability, interests, and preferred roles.</li>
              <li>Swipe through people and projects. When it’s mutual, form a team.</li>
              <li>Chat in real time, share tasks, and ship your build.</li>
            </ol>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-card to-muted/40 flex items-center justify-center">
          <img src="/placeholder.svg" alt="Project showcase" className="max-h-48 object-contain" />
        </Card>
      </section>

      <section className="mx-auto max-w-4xl text-center">
        <h3 className="text-2xl font-bold">Ready to match your stack?</h3>
        <p className="mt-2 text-muted-foreground">
          Create a profile, declare your skills, and meet your next teammate.
        </p>
        <div className="mt-5 flex items-center justify-center gap-3">
          <Button size="lg" asChild>
            <a href="/auth">Get started</a>
          </Button>
          <Button size="lg" variant="secondary" asChild>
            <a href="/add-project">Add a project</a>
          </Button>
        </div>
      </section>
    </div>
  );
}

function Feature({
  icon,
  title,
  desc,
}: {
  icon: ReactNode;
  title: string;
  desc: string;
}) {
  return (
    <Card className="border-muted bg-gradient-to-br from-card to-muted/40">
      <CardContent className="p-6">
        <div className="flex items-start gap-3">
          <div className="mt-1 inline-flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 text-primary">
            {icon}
          </div>
          <div>
            <h4 className="font-semibold">{title}</h4>
            <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
