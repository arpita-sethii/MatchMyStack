import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function MatchChat() {
  const [messages, setMessages] = useState<{ from: "them" | "you"; text: string }[]>([
    { from: "them", text: "Hey! Loved your profile — wanna team up for the weekend hackathon?" },
    { from: "you", text: "Yes! I'm available Sat-Sun. What role do you need?" },
  ]);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    setMessages((m) => [...m, { from: "you", text: input }]);
    setInput("");
  };

  const icebreakers = [
    "What's a recent project you're proud of?",
    "What role do you want to play in this project?",
    "Any stack preferences or hard constraints?",
  ];

  const [aiOpen, setAiOpen] = useState(false);
  const [aiQuery, setAiQuery] = useState("");
  const [aiResponses, setAiResponses] = useState<string[]>([]);

  const askAi = () => {
    if (!aiQuery.trim()) return;
    // Mock AI response
    setAiResponses((r) => [...r, `You asked: ${aiQuery}`, `Assistant: Here's a helpful tip for "${aiQuery}" (mock).`]);
    setAiQuery("");
  };

  return (
    <div className="mx-auto max-w-4xl">
      <Card>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Matched: Mina Patel</h3>
              <p className="text-sm text-muted-foreground">Backend / Infra — Postgres, Node</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-muted-foreground">Matched 2 hours ago</div>
              <Button variant="ghost" onClick={() => setAiOpen((s) => !s)}>AI Help</Button>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-3 gap-6">
            <div className="col-span-2 flex flex-col gap-4">
              <div className="flex-1 space-y-3 overflow-auto max-h-[50vh] p-2">
                {messages.map((m, i) => (
                  <div key={i} className={m.from === 'you' ? 'text-right' : 'text-left'}>
                    <div className={`inline-block rounded-md px-4 py-2 ${m.from === 'you' ? 'bg-primary text-primary-foreground' : 'bg-muted/40 text-muted-foreground'}`}>
                      {m.text}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex items-center gap-3">
                <input value={input} onChange={(e) => setInput(e.target.value)} className="flex-1 rounded-md border px-3 py-2" placeholder="Write a message..." onKeyDown={(e) => { if (e.key === 'Enter') send(); }} />
                <Button onClick={send}>Send</Button>
              </div>
            </div>

            <aside className="col-span-1 space-y-3">
              <div className="rounded-md border p-3">
                <h4 className="font-semibold">Icebreakers</h4>
                <div className="mt-2 flex flex-col gap-2">
                  {icebreakers.map((t) => (
                    <button key={t} onClick={() => setInput(t)} className="w-full rounded-md border px-3 py-2 text-left text-sm text-muted-foreground">{t}</button>
                  ))}
                </div>
              </div>

              <div className="rounded-md border p-3">
                <h4 className="font-semibold">Match info</h4>
                <p className="mt-2 text-sm text-muted-foreground">Role fit: 86% · Overlapping skills: Python, Docker</p>
              </div>

              {aiOpen && (
                <div className="rounded-md border p-3">
                  <h4 className="font-semibold">AI Assistant</h4>
                  <p className="mt-2 text-sm text-muted-foreground">Ask questions about collaboration, roles, or project ideas.</p>
                  <div className="mt-3 flex gap-2">
                    <input value={aiQuery} onChange={(e) => setAiQuery(e.target.value)} className="flex-1 rounded-md border px-3 py-2" placeholder="Ask the assistant..." onKeyDown={(e) => { if (e.key === 'Enter') askAi(); }} />
                    <Button onClick={askAi}>Ask</Button>
                  </div>
                  <div className="mt-3 space-y-2 text-sm">
                    {aiResponses.map((r, i) => (
                      <div key={i} className="rounded-md bg-muted/40 p-2">{r}</div>
                    ))}
                  </div>
                </div>
              )}
            </aside>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
