import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const sample = [
  {
    id: "p1",
    title: "Realtime Collab Editor",
    desc: "Collaborative text editor for workshops.",
    stack: ["React", "Node", "WebRTC"],
    roles: { need: 2, filled: 1 },
    deadline: Date.now() + 1000 * 60 * 60 * 24 * 3,
  },
  {
    id: "p2",
    title: "ML Model Playground",
    desc: "Try different models against standard datasets.",
    stack: ["Python", "PyTorch", "FastAPI"],
    roles: { need: 3, filled: 2 },
    deadline: Date.now() + 1000 * 60 * 60 * 24 * 7,
  },
];

function timeLeft(deadline: number) {
  const diff = Math.max(0, deadline - Date.now());
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  return `${days}d ${hours}h`;
}

export default function Projects() {
  return (
    <div className="mx-auto max-w-6xl">
      <h2 className="text-2xl font-bold mb-6">Projects & Teams</h2>
      <div className="grid gap-6 md:grid-cols-2">
        {sample.map((p) => (
          <Card key={p.id}>
            <CardContent>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{p.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
                  <div className="mt-3 flex gap-2">
                    {p.stack.map((s) => (
                      <Badge key={s} variant="secondary">{s}</Badge>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">Team: {p.roles.filled}/{p.roles.need}</div>
                  <div className="mt-2 font-medium">{timeLeft(p.deadline)}</div>
                  <div className="mt-4">
                    <Button>View</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
