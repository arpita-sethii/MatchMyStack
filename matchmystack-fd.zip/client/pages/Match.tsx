import { useState } from "react";
import SwipeDeck from "@/components/SwipeDeck";
import FiltersPanel from "@/components/FiltersPanel";
import { Button } from "@/components/ui/button";
import { Heart, Star, Video } from "lucide-react";

export default function Match() {
  const [showFilters, setShowFilters] = useState(false);

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex items-start gap-8">
        <div className="w-full md:w-2/3">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-2xl font-bold">Discover teammates</h2>
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={() => setShowFilters((s) => !s)}>Filters</Button>
              <Button variant="outline">My likes</Button>
            </div>
          </div>

          <div className="rounded-xl border p-6">
            <div className="flex items-center justify-between">
              <div className="w-48">
                <div className="h-2 w-full rounded-full bg-muted/40" />
                <div className="mt-1 text-xs text-muted-foreground">Role fit</div>
              </div>
              <div className="flex items-center gap-3">
                <Button variant="ghost" className="flex items-center gap-2"><Video className="h-4 w-4"/> Intro</Button>
                <Button variant="ghost" className="bg-gradient-to-tr from-pink-500/10 to-red-300/10"> <Star className="h-4 w-4"/> Super-like</Button>
              </div>
            </div>

            <div className="mt-6 flex justify-center">
              <SwipeDeck />
            </div>
          </div>
        </div>

        <aside className="hidden w-1/3 md:block">
          {showFilters ? <FiltersPanel /> : (
            <div className="sticky top-24 space-y-4">
              <div className="rounded-xl border p-4">
                <h4 className="font-semibold">Tips</h4>
                <p className="mt-2 text-sm text-muted-foreground">Use Super-like sparingly to highlight high-priority collaborators.</p>
              </div>

              <div className="rounded-xl border p-4">
                <h4 className="font-semibold">Match stats</h4>
                <p className="mt-2 text-sm text-muted-foreground">Your compatibility score is computed from skills, timezone and availability.</p>
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
