import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Github, Globe } from "lucide-react";

export default function Auth() {
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="mx-auto max-w-4xl">
      <div className="grid gap-8 md:grid-cols-2">
        <Card className="p-6">
          <CardContent>
            <h2 className="text-2xl font-bold">{isSignup ? "Create account" : "Welcome back"}</h2>
            <p className="mt-2 text-sm text-muted-foreground">Sign in to find teammates, join projects, and match with AI.</p>

            <form
              onSubmit={(e) => e.preventDefault()}
              className="mt-6 grid gap-3"
            >
              <label className="text-sm">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border px-3 py-2"
                placeholder="you@company.com"
              />

              <label className="text-sm">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border px-3 py-2"
                placeholder="••••••••"
              />

              <div className="mt-4 flex gap-3">
                <Button type="submit" size="lg">{isSignup ? "Create account" : "Sign in"}</Button>
                <Button variant="outline" onClick={() => setIsSignup(!isSignup)}>
                  {isSignup ? "Have an account? Sign in" : "New? Create account"}
                </Button>
              </div>

              <div className="mt-4 flex items-center gap-3">
                <hr className="flex-1 border-muted" />
                <span className="text-xs text-muted-foreground">or continue with</span>
                <hr className="flex-1 border-muted" />
              </div>

              <div className="mt-4 flex gap-3">
                <Button variant="ghost" asChild className="flex-1">
                  <a href="#" onClick={(e) => e.preventDefault()}>
                    <div className="flex items-center justify-center gap-2">
                      <Github className="h-4 w-4" /> GitHub
                    </div>
                  </a>
                </Button>
                <Button variant="ghost" asChild className="flex-1">
                  <a href="#" onClick={(e) => e.preventDefault()}>
                    <div className="flex items-center justify-center gap-2">
                      <Globe className="h-4 w-4" /> Google
                    </div>
                  </a>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card className="p-6">
            <CardContent>
              <h3 className="text-lg font-semibold">Why MatchMyStack?</h3>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li>AI-powered teammate matching based on skills and availability.</li>
                <li>Tinder-style swipe interface for fast discovery.</li>
                <li>Realtime chat and team formation tools.</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="p-6">
            <CardContent>
              <h3 className="text-lg font-semibold">Tips</h3>
              <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
                <li>Connect your GitHub to auto-import skills and repos.</li>
                <li>Fill out your availability and preferred roles for better matches.</li>
                <li>Add a short intro video to stand out.</li>
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
