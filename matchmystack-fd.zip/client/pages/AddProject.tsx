import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function AddProject() {
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState("");
  const [rolesNeeded, setRolesNeeded] = useState(3);
  const [deadline, setDeadline] = useState("");
  const [image, setImage] = useState<string | null>(null);

  const addSkill = () => {
    const s = skillInput.trim();
    if (s && !skills.includes(s)) setSkills((k) => [s, ...k]);
    setSkillInput("");
  };

  return (
    <div className="mx-auto max-w-4xl">
      <Card>
        <CardContent>
          <h2 className="text-2xl font-bold">Create a new project</h2>
          <p className="mt-2 text-sm text-muted-foreground">Add project info so teammates can find you.</p>

          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="md:col-span-1">
              <label className="text-sm">Project name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2" />

              <label className="mt-3 text-sm">Description</label>
              <textarea value={desc} onChange={(e) => setDesc(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2" rows={6} />

              <label className="mt-3 text-sm">Top skills required</label>
              <div className="mt-2 flex gap-2">
                <input value={skillInput} onChange={(e) => setSkillInput(e.target.value)} className="w-full rounded-md border px-3 py-2" onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addSkill(); } }} />
                <Button onClick={addSkill}>Add</Button>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {skills.map((s) => (
                  <Badge key={s} variant="secondary">{s}</Badge>
                ))}
              </div>

              <label className="mt-3 text-sm">Roles needed</label>
              <input type="number" min={1} value={rolesNeeded} onChange={(e) => setRolesNeeded(Number(e.target.value))} className="mt-1 w-28 rounded-md border px-3 py-2" />

              <label className="mt-3 text-sm">Deadline</label>
              <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2" />

              <div className="mt-4 flex items-center gap-3">
                <Button>Save project</Button>
                <Button variant="ghost">Cancel</Button>
              </div>
            </div>

            <div className="md:col-span-1">
              <label className="text-sm">Project image</label>
              <input
                type="file"
                accept="image/*"
                className="mt-2 w-full"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const url = URL.createObjectURL(f);
                  setImage(url);
                }}
              />

              {image && (
                <div className="mt-4">
                  <img src={image} alt="project" className="w-full rounded-md object-cover max-h-60" />
                </div>
              )}

              <div className="mt-6 rounded-md border p-3">
                <h4 className="font-semibold">Team picks</h4>
                <p className="mt-2 text-sm text-muted-foreground">Select teams you want to invite (mock).</p>
                <div className="mt-3 flex flex-col gap-2">
                  <label className="flex items-center gap-2"><input type="checkbox" /> Team Alpha</label>
                  <label className="flex items-center gap-2"><input type="checkbox" /> Team Beta</label>
                  <label className="flex items-center gap-2"><input type="checkbox" /> Team Gamma</label>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
