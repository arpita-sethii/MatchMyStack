import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Github, Sparkles, MessageSquare } from "lucide-react";

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-extrabold text-lg">
      <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground shadow-sm">
        <Sparkles className="h-4 w-4" />
      </span>
      <span>Match My Stack</span>
    </Link>
  );
}

const nav = [
  { to: "/match", label: "Discover" },
  { to: "/add-project", label: "Add Project" },
  { to: "/projects", label: "Projects" },
  { to: "/chat", label: "Chat" },
];

export default function AppShell() {
  const location = useLocation();
  return (
    <div className="min-h-dvh bg-gradient-to-b from-background via-background to-background">
      <header className="sticky top-0 z-40 w-full backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b">
        <div className="container flex h-16 items-center justify-between">
          <Logo />
          <nav className="hidden md:flex items-center gap-6">
            {nav.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    "text-sm font-medium text-muted-foreground hover:text-foreground transition-colors",
                    isActive && "text-foreground"
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" className="hidden sm:inline-flex">
              <a href="https://github.com" target="_blank" rel="noreferrer">
                <Github className="mr-2" /> GitHub
              </a>
            </Button>
            <Button asChild>
              <Link to="/auth">Login / Sign up</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="container py-12">
        <Outlet />
      </main>
      <footer className="border-t py-10 mt-10">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>
            © {new Date().getFullYear()} Match My Stack. Built for hackers, makers, and dreamers.
          </p>
          <div className="flex items-center gap-4">
            <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
            <Link to="/terms" className="hover:text-foreground">Terms</Link>
            <Link to="/contact" className="hover:text-foreground flex items-center gap-1">
              <MessageSquare className="h-4 w-4" /> Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
