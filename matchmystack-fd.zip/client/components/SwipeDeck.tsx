import { useMemo, useState } from "react";
import { motion, useAnimation } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface ProfileCard {
  id: string;
  name: string;
  role: string;
  bio: string;
  skills: string[];
}

const sample: ProfileCard[] = [
  {
    id: "1",
    name: "Ava Thompson",
    role: "ML Engineer",
    bio: "Kaggle grandmaster. Loves shipping tiny models that do big things.",
    skills: ["Python", "PyTorch", "LLMs", "Vector DB"],
  },
  {
    id: "2",
    name: "Leo Martinez",
    role: "Frontend + Design",
    bio: "Pixel-perfect UIs with performance budgets and motion love.",
    skills: ["React", "Tailwind", "Framer Motion", "Figma"],
  },
  {
    id: "3",
    name: "Mina Patel",
    role: "Backend/Infra",
    bio: "Fast APIs, clean schemas, reliable infra. Postgres first.",
    skills: ["Node", "Postgres", "Prisma", "Docker"],
  },
];

export default function SwipeDeck() {
  const [deck, setDeck] = useState<ProfileCard[]>(sample);
  const top = deck[0];
  const controls = useAnimation();

  const onSwipe = (dir: "left" | "right") => {
    controls.start({
      x: dir === "left" ? -500 : 500,
      rotate: dir === "left" ? -12 : 12,
      opacity: 0,
      transition: { duration: 0.3 },
    }).then(() => {
      setDeck((d) => d.slice(1).concat(d[0] ? [d[0]] : []));
      controls.set({ x: 0, rotate: 0, opacity: 1 });
    });
  };

  return (
    <div className="relative mx-auto h-[420px] w-full max-w-md">
      {deck
        .slice(0, 3)
        .reverse()
        .map((card, idx) => {
          const isTop = card.id === top?.id;
          return (
            <motion.div
              key={card.id}
              className={cn(
                "absolute inset-0 origin-bottom rounded-2xl",
                idx === 0 && "translate-y-0",
                idx === 1 && "translate-y-3 scale-[0.985]",
                idx === 2 && "translate-y-6 scale-[0.97]"
              )}
              style={{ zIndex: 10 - idx }}
              animate={isTop ? controls : undefined}
              drag={isTop ? "x" : false}
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.2}
              onDragEnd={(_, info) => {
                if (info.offset.x > 120) onSwipe("right");
                else if (info.offset.x < -120) onSwipe("left");
              }}
            >
              <Card className="h-full overflow-hidden border-muted bg-gradient-to-br from-card to-muted/40 shadow-xl">
                <CardContent className="h-full p-6">
                  <div className="flex h-full flex-col">
                    <div className="flex-1">
                      <div className="mb-2 text-xs uppercase tracking-wider text-muted-foreground">{card.role}</div>
                      <h3 className="text-2xl font-bold leading-tight">{card.name}</h3>
                      <p className="mt-2 text-sm text-muted-foreground">{card.bio}</p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {card.skills.map((s) => (
                          <Badge key={s} variant="secondary">{s}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="mt-6 grid grid-cols-2 gap-3">
                      <button
                        onClick={() => onSwipe("left")}
                        className="h-11 rounded-md border bg-background/70 text-sm font-medium text-muted-foreground backdrop-blur transition hover:bg-accent hover:text-foreground"
                      >
                        Pass
                      </button>
                      <button
                        onClick={() => onSwipe("right")}
                        className="h-11 rounded-md bg-primary text-primary-foreground text-sm font-medium shadow hover:bg-primary/90"
                      >
                        Match
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
    </div>
  );
}
